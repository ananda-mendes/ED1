int questao1 (int *vetor, int n);
void questao2 (int *vetor, int n, int i);
int questao3 (int n1, int n2);
int questao4 (int n);

