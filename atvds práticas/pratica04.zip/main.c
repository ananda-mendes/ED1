#include <stdio.h>
#include <stdlib.h>
#include "funcoes-recursivas.h"

int main()
{
	int n;
	scanf ("%d", &n);
	int *vetor = malloc (n * sizeof (int));
	for (int i = 0; i < n; i++) {
		scanf ("%d", &vetor[i]);
	}
	int soma = questao1 (vetor, n);
	printf ("A soma de todos elementos do vetor e: %d\n", soma);
	questao2 (vetor, n, 0);
	for (int i=0; i < n; i++) {
		printf ("Vetor Trocado [%d] = %d\n", i, vetor[i]);
	}
	int n1, n2; 
	scanf ("%d %d", &n1, &n2);
	int mod = questao3 (n1, n2);
	printf ("MOD = %d\n", mod);
	int nro; 
	scanf ("%d", &nro);
	int s = questao4 (nro);
	printf ("Soma de 1 a %d = %d\n", nro, s);
	
	return 0;
}

