#include "funcoes-recursivas.h"


int questao1 (int *vetor, int n) {
	if (n == 0) {
		return 0;
	} else {
		return vetor[n-1]+questao1(vetor, n-1);
	}
}

void questao2 (int *vetor, int n, int i) {
	if (n-1 <= i) {
		return;
	}
	else {
		int aux = vetor [i];
		vetor[i] = vetor [n-1];
		vetor[n-1] = aux;
		return questao2 (vetor, n-1, i+1);
	}
}
	
int questao3 (int n1, int n2) {
	if (n1 == n2) {
		return 0;
	}
	else if (n1 < n2) {
		return n1;
	}
	else {
		return questao3(n1-n2, n2);
	}
}

int questao4 (int n) {
	if (n == 1) {
		return 1;
	}
	else {
		return n+questao4(n-1);
	}
}
