#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aluno.h"

struct aluno{
	char nome[50];
	int cpf;
	int mat;
	char curso[50];
	char data[10];
};

Aluno *criaAluno(char nome[50], int cpf, int mat, char curso[50], char data[10]){
	Aluno *a = malloc(sizeof(Aluno));
	strcpy(a->nome, nome);
	a->cpf = cpf;
	a->mat = mat;
	strcpy(a->curso, curso);
	strcpy(a->data, data);
	return a;
}

void apagaAluno(Aluno *a){
	free(a);
}

Aluno* atualizaAluno(Aluno *a, char nome[50], int cpf, int mat, char curso[50], char data[10]){
 	setNomeAluno(a, nome);
	setCPFAluno(a, cpf);
	setMatAluno(a, mat);
	setCursoAluno(a, curso);
	setDataAluno(a, data);
	return a;
}

void lerAluno(Aluno *a){
	printf("\n\nAluno:\n");
	printf("Nome: %s", getNomeAluno(a));
	printf("\nCPF: %d", getCPFAluno(a));
	printf("\nMatricula: %d", getMatAluno(a));
	printf("\nCurso: %s", getCursoAluno(a));
	printf("\nData de ingresso: %s", getDataAluno(a));

}

char* getNomeAluno(Aluno *a){
	return a->nome;
}

int getCPFAluno(Aluno *a){
	return a->cpf;
}

int getMatAluno(Aluno *a){
	return a->mat;
}

char* getCursoAluno(Aluno *a){
	return a->curso;
}

char* getDataAluno(Aluno *a){
	return a->data;
}

void setNomeAluno(Aluno *a, char nome[50]){
	strcpy (a->nome, nome);
}

void setCPFAluno(Aluno *a, int cpf){
	a->cpf = cpf;
}

void setMatAluno(Aluno *a, int mat){
	a->mat = mat;
}

void setCursoAluno(Aluno *a, char curso[50]){
	strcpy (a->curso, curso);
}

void setDataAluno(Aluno *a, char data[10]){
	strcpy (a->data, data);
}
