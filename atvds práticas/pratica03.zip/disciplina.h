typedef struct disciplina Disciplina;

// Funcoes de uso geral

Disciplina* criaD(char nome[50], char codigo[10], int carga, char curso[50], int sala);

void apagaD(Disciplina *d);

Disciplina* atualizaD(Disciplina *d, char nome[50], char codigo[10], int carga, char curso[50], int sala);

void lerD(Disciplina *d);

// USANDO GET E SET

char* getNomeD(Disciplina *d);

char* getCodigoD(Disciplina *d);

int getCargaD(Disciplina *d);

char* getCursoD(Disciplina *d);

int getSalaD(Disciplina *d);


void setNomeD(Disciplina *d, char nome[50]);

void setCodigoD(Disciplina *d, char codigo[10]);

void setCargaD(Disciplina *d, int carga);

void setCursoD(Disciplina *d, char curso[50]);

void setSalaD(Disciplina *d, int sala);
