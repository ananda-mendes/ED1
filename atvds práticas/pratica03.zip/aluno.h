typedef struct aluno Aluno;

// Funcoes de uso geral

Aluno* criaAluno(char nome[50], int cpf, int mat, char curso[50], char data[10]);

void apagaAluno(Aluno *a);

Aluno* atualizaAluno(Aluno *a, char nome[50], int cpf, int mat, char curso[50], char data[10]);

void lerAluno(Aluno *a);

// USANDO GET e SET

char* getNomeAluno(Aluno *a);

int getCPFAluno(Aluno *a);

int getMatAluno(Aluno *a);

char* getCursoAluno(Aluno *a);

char* getDataAluno(Aluno *a);


void setNomeAluno(Aluno *a, char nome[50]);

void setCPFAluno(Aluno *a, int cpf);

void setMatAluno(Aluno *a, int mat);

void setCursoAluno(Aluno *a, char curso[50]);

void setDataAluno(Aluno *a, char data[10]);

