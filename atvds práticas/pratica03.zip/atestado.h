#include "aluno.h"
#include "disciplina.h"


// Funcoes de uso geral
typedef struct atestado Atestado;

Atestado* criaAt(Aluno *a, Disciplina **d, int horas);

void apagaAt(Atestado *at);

void lerAt(Atestado *at);

// USANDO GET e SET

Aluno* getAluno(Atestado* at);

Disciplina* getDisciplina(Atestado *at, int aux);

int getHoras(Atestado *at);


void setAluno(Atestado* at, Aluno* a);

void setDisciplina(Atestado *at, Disciplina *d, int aux);

void setHoras(Atestado *at, int horas);
