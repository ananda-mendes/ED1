#include <stdio.h>
#include <stdlib.h>
#include "aluno.h"
#include "disciplina.h"
#include "atestado.h"


struct atestado{
	Aluno *aluno;
	Disciplina **disciplina;
	int horas;
};

Atestado *criaAt(Aluno *a, Disciplina **d, int horas){
	Atestado *at = malloc(sizeof(Atestado));
	at->aluno = a;
	at->disciplina = d;
	at->horas = horas;
	return at;
}

void apagaAt(Atestado *at){
	for (int i=0; i < at->horas/4; i++) 
	{
		apagaD (getDisciplina(at, i));
	}
	apagaAluno (getAluno(at));
	free (at->disciplina);
	free(at);
}

void lerAt(Atestado *at){
	printf("\n\nAtestado de Matricula:");
	lerAluno(getAluno(at));
	for(int i = 0; i < at->horas/4; i++){
		lerD(getDisciplina(at, i));
	}
	printf("\n\nHoras-aula total: %d\n", getHoras(at));
}

Aluno* getAluno(Atestado* at){
	return at->aluno;
}

Disciplina* getDisciplina(Atestado *at, int aux){
	return at->disciplina[aux];
}

int getHoras(Atestado *at){
	return at->horas;
}

void setAluno(Atestado* at, Aluno* a){
	at->aluno = a;
}

void setDisciplina(Atestado *at, Disciplina *d, int aux){
	at->disciplina[aux] = d;
}

void setHoras(Atestado *at, int horas){
	at->horas = horas;
}
