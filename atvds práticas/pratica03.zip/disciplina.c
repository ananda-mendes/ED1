#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "disciplina.h"

struct disciplina{
	char nome[50];
	char codigo[10];
	int carga;
	char curso[50];
	int sala;
};

Disciplina *criaD(char nome[50], char codigo[10], int carga, char curso[50], int sala){
	Disciplina *d = malloc(sizeof(Disciplina));
	strcpy(d->nome, nome);
	strcpy(d->codigo, codigo);
	d->carga = carga;
	strcpy(d->curso, curso);
	d->sala = sala;
	return d;
}

void apagaD(Disciplina *d){
	free(d);
}

Disciplina* atualizaD(Disciplina *d, char nome[50], char codigo[10], int carga, char curso[50], int sala){
	setNomeD(d, nome);
	setCodigoD(d, codigo);
	setCargaD(d, carga);
	setCursoD(d, curso);
	setSalaD(d, sala);
	return d;
}

void lerD(Disciplina *d){
	printf("\n\nDisciplina:\n");
	printf("Nome: %s", getNomeD(d));
	printf("\nCodigo: %s", getCodigoD(d));
	printf("\nCarga Horaria: %d", getCargaD(d));
	printf("\nCurso: %s", getCursoD(d));
	printf("\nSala: %d", getSalaD(d));
}

char* getNomeD(Disciplina *d){
	return d->nome;
}

char* getCodigoD(Disciplina *d){
	return d->codigo;
}

int getCargaD(Disciplina *d){
	return d->carga;
}

char* getCursoD(Disciplina *d){
	return d->curso;
}

int getSalaD(Disciplina *d){
	return d->sala;
}


void setNomeD(Disciplina *d, char nome[50]){
	strcpy (d->nome, nome);
}

void setCodigoD(Disciplina *d, char codigo[10]){
	strcpy (d->codigo, codigo);
}

void setCargaD(Disciplina *d, int carga){
	d->carga = carga;
}

void setCursoD(Disciplina *d, char curso[50]){
	strcpy (d->curso, curso);
}

void setSalaD(Disciplina *d, int sala){
	d->sala = sala;
}

