#include <stdio.h>
#include <stdlib.h>
#include "aluno.h"
#include "disciplina.h"
#include "atestado.h"

int main(){
	Aluno *a;
	Atestado *at;
	Disciplina **d = malloc(4*sizeof(Disciplina*));
	char nome[50];
	char codigo[10];
	int carga;
	char curso[50];
	int sala;
	int horas = 0;
	for (int i=0; i < 4; i++)
	{
		if(horas > 16)
		{
			break;
		}
		else{
			scanf("%s", nome);
			scanf("%s", codigo);
			scanf("%d", &carga);
			horas += carga;
			scanf("%s", curso);
			scanf("%d", &sala);
			d[i] = criaD(nome, codigo, carga, curso, sala);
		}
	}
	a = criaAluno("Ananda", 01723326553, 1914030, "Computacao", "12/03/2019");

	at = criaAt(a, d, horas);
	lerAt(at);
	return 0;
}
