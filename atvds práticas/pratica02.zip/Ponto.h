#ifndef Ponto_H
#define Ponto_H

typedef struct ponto Ponto;

Ponto* criarPt (float x, float y);
void liberarPt (Ponto *pt);
void acessarPt (Ponto *pt, float* x, float *y);
void atribuirPt (Ponto *pt, float x, float y);

#endif
