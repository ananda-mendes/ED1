#include <stdio.h>
#include <stdlib.h>
#include "Ponto.h"

struct ponto {
  float x, y;
};

Ponto *criarPt (float x, float y) {
  Ponto *aux = malloc (sizeof (Ponto));
  aux->x = x;
  aux->y= y;
  return aux;
}

void liberarPt (Ponto* pt) {
    free (pt);
}

void acessarPt (Ponto* pt, float* x, float *y) {
  *x = pt->x;
  *y = pt->y;
}

void atribuirPt (Ponto* pt, float x, float y) {
  pt->x = x;
  pt->y = y;
}
