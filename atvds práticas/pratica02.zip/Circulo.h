#ifndef Circulo_H
#define Circulo_H
#include "Ponto.h"
typedef struct circulo Circulo;

Circulo *criarCir (float r, Ponto* pt);
void liberarCir (Circulo *cir);
double calcularACir (Circulo *cir);

#endif
