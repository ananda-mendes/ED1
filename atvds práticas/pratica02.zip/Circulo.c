#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Circulo.h"
#include "Ponto.h"
#define pi 3.141592

struct circulo {
  Ponto* p;
  float r;
};

Circulo *criarCir (float r, Ponto *p) {
  Circulo *aux = malloc (sizeof (Circulo));
  aux->r = r;
  aux->p = p;
  return aux;
}
void liberarCir (Circulo *cir) {
  free (cir);
}
double calcularACir (Circulo *cir) {
  double area = pi * pow (cir->r,2);
  return area;
}
