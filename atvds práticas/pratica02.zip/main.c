#include <stdio.h>
#include <stdlib.h>
#include "Ponto.h"
#include "Circulo.h"

int main () {
  Ponto *pt;
  float x, y;
  Circulo *cir;
  float r;

  // Criando o Ponto
  pt = criarPt (2.0, 3.0);

  //Acessando o Ponto
  acessarPt (pt, &x, &y);
  printf ("x = %.1f e y = %.1f\n\n", x,y);

  //atribuindo novos valores ao Ponto
  atribuirPt (pt, 3.0, 5.0);

  //Criando o Circulo
  cir = criarCir (5.0, pt);

  //Calculando Area do Circulo
  double area = calcularACir (cir);
  printf ("A area eh: %.1lf\n", area);

  //Liberando Memoria
  liberarPt (pt);
  liberarCir (cir);

  return 0;



}
