
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

void questao1 (int qtd, double cosx);
void questao2 (int n);
void questao3 (int qtd3);
void valorMatriz (int linha, int coluna, int maiorv, int menorv, double media);
void questao4 (int nquestoes, int qtdalunos);

int main(int argc, char **argv)
{
	double cosx = 1;
	int qtd, qtd3;
	int n;
	int nquestoes, qtdalunos;
	scanf ("%d", &qtd); // lendo a quantidade de vezes que será realizado o calculo da questao 1
	questao1 (qtd, cosx);
	scanf ("%d", &n); // lendo o numero de simulacoes da questao 2
	questao2 (n);
	scanf ("%d", &qtd3); // lendo a quantidade de matrizes a serem computadas na questao3
	questao3 (qtd3);
	scanf ("%d %d", &nquestoes, &qtdalunos); //lendo o numero de questoes e numero de alunos da questao 4
	questao4 (nquestoes, qtdalunos);
	
	return 0;
}

//implementando a questao 1
void questao1 (int qtd, double cosx)
{
	printf ("\n***********QUESTAO 1***********\n\n");
	double x;
	int n, aux, exp, num, sinal;
	long double fat;
	for (int i=0; i < qtd; i++)
	{
		scanf ("\n%lf %d\n", &x, &n);
		exp = 2, num = 2;
		x = x * 0.0174532925; //convertendo de graus pra radianos
		sinal = -1;
		for (int k = 0; k < n; k++)
		{
			aux = num;
			fat = 1;
			for (int j = 0; j < num ; j++)
			{
				fat = fat * aux;
				aux--;
			}
			cosx += (pow (x,exp)/fat) * sinal;
			sinal *= -1;
			exp += 2;
			num += 2;
		}
		printf ("%.2lf %d %.5lf\n", x, n, cosx);
		cosx = 1;
	}
}

// implementacao questao 2
void questao2 (int n)
{
	printf ("\n\n\n");
	printf ("***********QUESTAO 2***********\n\n");
	int m,cont=1;
	double montanteA, rendimentoA, depositoA, montanteB, rendimentoB;
	for (int i=0; i < n; i++)
	{
		scanf ("%lf %lf %lf %lf %lf %d\n", &montanteA, &depositoA, &rendimentoA, &montanteB, &rendimentoB, &m);
		if (montanteB > montanteA)
		{
			printf ("Rendimento de B invalido\n");
			continue;
		}
		for (int j = 0; j < m; j++)
		{
			montanteA *= 1 + (rendimentoA/100);
			montanteA += depositoA;
			montanteB *= 1 + (rendimentoB/100);
			if (montanteB < montanteA)
			{
				cont++;
			}
		}
		if (cont > m)
		{
			printf ("%.2lf %.2lf B nao supera A\n", montanteA, montanteB);
		}
		else 
		{
			printf ("%.2lf %.2lf %d\n", montanteA, montanteB, cont);
		}
	}
}

//implementando a questao 3
void questao3 (int qtd3)
{
	printf ("\n\n\n");
	printf ("***********QUESTAO 3***********\n\n");
	int linha, coluna, maiorv=0, menorv = 10000;
	double media=0;
	for (int i=0; i < qtd3; i++)
	{
		scanf ("%d %d", &linha, &coluna);
		valorMatriz (linha, coluna, maiorv, menorv, media);
	}
}
void valorMatriz (int linha, int coluna, int maiorv, int menorv, double media)
{
	int **matriz = malloc (linha * sizeof (int*));
	for (int i = 0; i < linha; i++)
	{
		matriz[i] = malloc (coluna * sizeof (int));
		for (int j = 0; j < coluna; j++)
		{
			scanf ("%d", &matriz[i][j]);
			if (matriz[i][j] > maiorv)
			{
				maiorv = matriz[i][j];
			}
			if (matriz[i][j] < menorv)
			{
				menorv = matriz[i][j];
			} 
			media += (matriz[i][j]);
			
		}
	}
	media /= (linha * coluna);
	printf ("%d %d %.3lf\n", maiorv, menorv, media);
	media = 0;
	maiorv = 0;
	menorv = 10000;
	for (int i=0; i < linha; i++)
	{
		free (matriz[i]);
	}
	free (matriz);
}

//implementando questao 4
void questao4 (int nquestoes, int qtdalunos)
{
	printf ("\n\n\n");
	printf ("***********QUESTAO 4***********\n\n");
	int cont = 0;
	int *gabarito = malloc (nquestoes * sizeof (int));
	int *chamada = malloc (qtdalunos * sizeof (int));
	for (int i=0; i < nquestoes; i++)
	{
		scanf ("%d", &gabarito[i]);
	}
	int **respostas = malloc (qtdalunos * sizeof (int*));
	for (int i=0; i < qtdalunos; i++)
	{
		respostas[i] = malloc (nquestoes * sizeof (int));
		for (int j=0; j < nquestoes; j++)
		{
			scanf ("%d", &respostas[i][j]);
			if (respostas[i][j] == gabarito[j])
			{
				cont++;
			}
		}
		scanf ("%d", &chamada[i]);
		printf ("%d %d\n", chamada[i], cont);
		cont = 0;
	}
	free (gabarito);
	free (chamada);
	for (int i=0; i < qtdalunos; i++)
	{
		free (respostas[i]);
	}
	free(respostas);
}
