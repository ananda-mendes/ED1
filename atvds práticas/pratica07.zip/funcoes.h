#ifndef FUNCOES_H
#define FUNCOES_H

void radix (int *v, int n);
void count (int *v, int n, int exp);

#endif
