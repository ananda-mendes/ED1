#include <stdio.h>
#include <stdlib.h> 
#include "funcoes.h"

int main()
{
	int n;
	scanf ("%d", &n);
	int *v = malloc (n * sizeof (int));
	for (int i = 0; i < n; i++) {
		v[i] = rand () % (n - 1);
	}
	printf ("VETOR DESORDENADO\n\n");
	for (int i=0; i < n; i++) {
		printf ("%d ", v[i]);
	}
	
	radix (v, n);
	printf ("\n\nVETOR ORDENADO\n\n");
	for (int i=0; i < n; i++) {
		printf ("%d ", v[i]);
	}
	free (v);
	return 0;
}

