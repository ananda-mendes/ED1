#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

void radix (int *v, int n) {
	int maior;
	for (int i=0; i < n; i++) {
		if (v[i] > maior) {
			maior = v[i];
		}
	}
	
	for (int exp = 1; (maior/exp) > 0; exp *= 10) {
		count (v, n, exp);
	}
	
}

void count (int *v, int n, int exp) {
	int *aux = calloc (n, sizeof (int));
	int *cont = calloc (10, sizeof (int));
	int i;
	for (i=0; i < n; i++) {
		cont[(v[i]/exp)%10]++; 
	}
	for (i = 1; i < 10; i++) {
		cont[i] += cont[i - 1]; 
	}
	for (i = n - 1; i >= 0; i--) 
	{ 
		aux[cont[(v[i]/exp)%10] - 1] = v[i]; 
		cont[(v[i]/exp)%10]--; 
	} 

	for (i = 0; i < n; i++) {
		v[i] = aux[i]; 
	}
	free (cont);
	free (aux);
} 

	
	
