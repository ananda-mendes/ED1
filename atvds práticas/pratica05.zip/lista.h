//TAD LISTA 

#ifndef LISTA_H
#define LISTA_H

typedef struct lista Lista;

Lista* lst_cria (void);
void lst_libera (Lista *l);
void lst_insere (Lista *l, int v);
void lst_insere_final (Lista *l, int v);
int lst_pertence (Lista *l, int v);
void lst_insere_ordenado (Lista* l, int v);
void lst_retirar (Lista* l, int v);
int lst_vazia (Lista* l);
void lst_imprime(Lista* l);

#endif


