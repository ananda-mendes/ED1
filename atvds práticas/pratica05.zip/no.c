#include <stdio.h>
#include <stdlib.h>
#include "no.h"

struct no {
int dado;
No* prox;

};

No* criaNo(){
No* n = malloc(sizeof(No));
n->dado = 0;
n->prox = NULL;
return n;
}

void liberaNo (No *n) {
	free(n);
}

int getDadoNo(No* n){
return n->dado;
}

void setDadoNo(No* n, int v) {
n->dado = v;
}

No* getProxNo(No* n) {
return n->prox;
}

void setProxNo(No* n, No* prox){
n->prox = prox;
}
