//TAD NO

#ifndef NO_H
#define NO_H

typedef struct no No;

No* criaNo (void); 
void liberaNo (No *n);
int lst_pertence_no (No *n, int v);

int getDadoNo (No *n);
No* getProxNo (No *n);

void setDadoNo (No *n, int v);
void setProxNo (No *n, No* prox);


#endif

