#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "no.h"

struct lista {
	No* prim;
	No* ult;
};

Lista* lst_cria (void) {
	Lista *l = malloc (sizeof (Lista));
	l->prim = NULL;
	l->ult = NULL;
	return l;
}

void lst_libera (Lista *l) {
	No *aux = l->prim;
	No *ant = NULL;
	
	while (aux != NULL) {
		ant = aux;
		free(ant);
		aux = getProxNo(aux);
	}
	free(l);
}

void lst_insere (Lista *l, int v) {
	No* aux = l->prim;
	No *nv = criaNo ();
	setDadoNo (nv, v);
	
	if (aux == NULL) {
		l->prim = nv;
		l->ult = nv;
		setProxNo (nv, NULL); 
	}
	else {
		l->prim = nv;
		setProxNo (nv, aux);
	}
}

void lst_insere_final (Lista *l, int v) {
	No *aux = l->ult;
	No *nv = criaNo ();
	setDadoNo (nv, v);
	
	if (aux == NULL) {
		l->prim = nv;
		l->ult = nv;
		setProxNo (nv, NULL);
	}
	else {
		setProxNo (aux, nv);
		l->ult = nv;
		setProxNo (nv,NULL);
	}
}


int lst_pertence (Lista *l, int v) {
	if (lst_pertence_no(l->prim, v) == 0) {
		return 0;
	}
	else {
		return 1;
	}
}

int lst_pertence_no (No *n, int v) {
	if (getDadoNo(n) == v) {
		return 1;
	}
	else {
		if (getProxNo(n) != NULL)  {
			return lst_pertence_no (getProxNo(n), v);
		}
		else {
			return 0;
		}
	}
}
 
void lst_insere_ordenado (Lista* l, int v){
	No* ant = NULL; 
	No* p= l->prim; 
	
	while (p!=NULL && getDadoNo(p) < v){
		ant = p;
		p = getProxNo (p);
	}
	
	No* novo = criaNo ();
	setDadoNo (novo, v);

	
	if (ant == NULL ){
		setProxNo (novo, l->prim);
		l->prim= novo;
	}
	else{
		setProxNo (novo, ant);
		setProxNo (ant, novo);
	}
}

void lst_retirar (Lista* l, int v){
	No* ant = NULL; 	
	No* p= l->prim; 
	
	while (p!=NULL && getDadoNo (p) !=v){
		ant=p;
		p = getProxNo (p);
	}
	
	if (p!=NULL){
		if(ant==NULL) {
			l->prim= getProxNo (p);
		} 
		else {
			setProxNo (ant, p);
		}
		free (p);
	}
}
	
int lst_vazia (Lista* l){
	return (l->prim==NULL);
}

void lst_imprime(Lista* l){
	No* nv = l->prim;
	int dado;
	printf ("\nLista:\n");
	while(nv != NULL){
		dado = getDadoNo(nv);
		printf("%d\n",dado);
		nv = getProxNo (nv);
	}
}
