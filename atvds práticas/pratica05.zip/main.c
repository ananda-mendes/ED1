#include <stdio.h>
#include <stdlib.h> 
#include "lista.h"
#include "no.h"

int main()
{
	Lista *l = lst_cria ();
	No *n = criaNo ();
	int inicio, final, procura;
	printf ("Digite 3 numeros: ");
	scanf ("%d %d %d", &inicio, &final, &procura);
	lst_insere (l, inicio);
	lst_insere_final (l, final);
	int retorno = lst_pertence (l, procura);
	if (retorno == 1) {
		printf ("\nO numero %d esta dentro da lista\n", procura);
	}
	else {
		printf ("\nO numero %d nao esta dentro da lista\n", procura);
	}
	printf ("\nDigite um numero pra ser retirado: ");
	int v;
	scanf ("%d", &v);
	lst_retirar (l, v);
	lst_imprime (l);
	lst_libera(l);
	liberaNo (n);
	
	return 0;
}

