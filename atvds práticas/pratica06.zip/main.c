#include <stdio.h>
#include "ordenacao.h"
#include "geracaoVetores.h"
#include <time.h>
#include <stdlib.h>

int main()
{
	srand(time(NULL));
	int n;
	int *v = malloc (n * sizeof (int));
	scanf ("%d", &n);
	
	time_t rawtime;
    struct tm * timeinfo;
    time ( &rawtime );
    timeinfo=localtime( &rawtime );
    printf("Data atual do sistema: %s\n", asctime (timeinfo) );
    
    
    
	v = aleatorio (n);
	bubble (v, n);
	printf ("BUBBLESORT ALEATORIO\n");
	for (int i=0; i < n; i++) {
		printf ("%d ", v[i]);
	}
	
	/*
	v = aleatorio (n);
	selection (v, n);
	printf ("\n\nSELECTIONSORT ALEATORIO\n");
	
	
	
	v = aleatorio (n);
	insertion (v, n);
	printf ("\n\nINSERTIONSORT ALEATORIO\n");
	
	v = aleatorio (n);
	mergeSort (v, n);
	printf ("\n\nMERGESORT ALEATORIO\n");
	
	v = crescente (n);
	bubble (v, n);
	printf ("\n\nBUBBLESORT CRESCENTE\n");
	
	
	v = crescente (n);
	selection (v, n);
	printf ("\n\nSELECTIONSORT CRESCENTE\n");
	
	v = crescente (n);
	insertion (v, n);
	printf ("\n\nINSERTIONSORT CRESCENTE\n");

	v = crescente (n);
	mergeSort (v, n);
	printf ("\n\nMERGESORT CRESCENTE\n");
	
	
	v = decrescente (n);
	bubble (v, n);
	printf ("\n\nBUBBLESORT DECRESCENTE\n");
	
	v = decrescente (n);
	selection (v, n);
	printf ("\n\nSELECTIONSORT DECRESCENTE\n");

	
	v = decrescente (n);
	insertion (v, n);
	printf ("\n\nINSERTIONSORT DECRESCENTE\n");
	
	
	v = decrescente (n);
	mergeSort (v, n);
	printf ("\n\nMERGESORT DECRESCENTE\n");
	 */
	
	time ( &rawtime );
    timeinfo=localtime( &rawtime );
	printf("\n\nData atual do sistema: %s", asctime (timeinfo) );
	
	free (v);
	return 0;
}

