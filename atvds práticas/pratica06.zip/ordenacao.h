//TAD ORDENACAO

#ifndef ORDENACAO_H
#define ORDENACAO_H


void bubble (int *v, int n);
void selection (int *v, int n);
void insertion (int *v, int n);
int pesquisaBinaria (int *v, int chave, int esq, int dir);
void mergeSort (int *v, int n);
void mergeSort_ordena (int *v, int esq, int dir);
void mergeSort_intercala (int *v, int esq, int meio, int dir);
#endif
