//TAD GERAR VETORES

#ifndef GERACAOVETORES_H
#define GERACAOVETORES_H

int *aleatorio (int n);
int *crescente (int n);
int *decrescente (int n);

#endif
