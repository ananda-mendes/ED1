#include <stdio.h>
#include <stdlib.h>
#include "ordenacao.h"

	
void bubble (int *v, int n) {
	int troca, aux;
	for (int i = 0; i < n - 1; i ++) {
		troca = 0;
		for (int j = 1; j < n - i; j++) {
			if ( v[j] < v[j-1] ) {
				aux = v[j];
				v[j] = v [j-1];
				v[j-1] = aux;
				troca ++;
			}
		}
		if ( troca == 0) {
			break;
		}
	}
}

void selection (int *v, int n) {
	int max, aux, j;
	for (int i = n-1; i >= 0; i--) {
		max = i;
		for (j = 0; j <= i; j++) {
			if ( v[j] > v[max] ) {
				max = j;
			}
		}
		if ( i != max ) {
			aux = v[max];
			v[max] = v[i];
			v[i] = aux;
		}
	}
 }

void insertion (int *v, int n) {
	int i, j, pos, aux;
	for (i = 1; i < n; i++) 
    { 
        j = i - 1; 
        aux = v[i]; 
       
        pos = pesquisaBinaria(v, aux, 0, j); 
        
        while (j >= pos) 
        { 
            v[j+1] = v[j]; 
            j--; 
        } 
        v[j+1] = aux; 
    } 
} 


void mergeSort (int *v, int n) {
	mergeSort_ordena (v, 0, n-1);
}

void mergeSort_ordena (int *v, int esq, int dir) {
	if ( esq >= dir ) {
		return;
	}
	int meio = ( esq + dir ) / 2;
	mergeSort_ordena (v , esq, meio );
	mergeSort_ordena (v , meio+1, dir );
	mergeSort_intercala (v , esq, meio , dir );
	return;
}

void mergeSort_intercala (int *v, int esq, int meio, int dir) {
	int i , j , k ;
	int a_tam = meio - esq +1;
	int b_tam = dir - meio ;
	int *a = malloc (a_tam * sizeof (int));
	int *b = malloc (b_tam * sizeof (int));
	
	for (i = 0; i < a_tam; i ++) {
		a[i] = v[i+esq];
	}
	for (i = 0; i < b_tam; i ++) {
		b[i] = v[i+ meio+1];
	}
	for (i = 0, j = 0 , k = esq ; k <= dir ; k ++) {
		if (i == a_tam ) {
			v[k] = b[j++];
		}
		else if ( j == b_tam ) {
			v[k] = a[i++];
		}
		else if ( a[i] < b[j] ) {
			v[k] = a[i++];
		}
		else {
			v [k] = b[j++];
		}
	}
	free (a);
	free (b);
}

int pesquisaBinaria (int *v, int chave, int esq, int dir) {
	if (dir<=esq){
		return (chave>v[esq])? (esq+1): esq;
	}

	int meio = (dir + esq)/2;

	if (chave == v[meio]) {
		return meio+1;
	}
	else if (chave > v[meio]) {
		return pesquisaBinaria(v, chave, meio+1, dir);
	}
	else {
		return pesquisaBinaria (v, chave, esq, meio-1);
	}
}

