#include <stdio.h>
#include <stdlib.h> 
#include "geracaoVetores.h"

int *aleatorio (int n) {
	int *v = malloc (n * sizeof (int));
	for (int i = 0; i < n; i++) {
		v[i] = rand () % (n - 1);
	}
	return v;
}

int *crescente (int n) {
	int *v = malloc (n * sizeof (int));
	for (int i = 0; i < n; i++) {
		v[i] = i;
	}
	return v;
}

int *decrescente (int n) {
	int *v = malloc (n * sizeof (int));
	int aux=0;
	for (int i = n; i >= 0; i--) {
		v[aux] = i;
		aux++;
	}
	return v;
}

